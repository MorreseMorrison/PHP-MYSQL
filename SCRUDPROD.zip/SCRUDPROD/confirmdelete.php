<?php

//11-9-2021 SCRUD 3 (1)
require "dbinfo.php";
$sel_record = $_POST['sel_record'];


//SQL statement to select information
//11-9-2021 SCRUD 3 (1)
// (12) 11/25/2021 - Swapped out contacts table with aliens_abduction
$sql = "SELECT * FROM aliens_abduction WHERE id = $sel_record";

    // (12) - 11/25/2021 - Added aditional variables to line up with output requirements
   // execute SQL query and get result
   //11-9-2021 SCRUD 3 (1)
if($result = mysqli_query($connection,$sql)){
        //Loop Through Record and Get Values
        while ($record = mysqli_fetch_array($result)) {
                $id = $record['id'];
                $fname = $record['first_name'];
                $lname = $record['last_name'];
                $email = $record['email'];
                $when=$record['when_it_happened'];
                $long=$record['how_long'];
                $how=$record['how_many'];
                $description=$record['alien_description'];
                $what=$record['what_they_did'];
                $add=$record['other'];

        }
        //End While Loop
        //11-9-2021 SCRUD 3 (1)
        // (11) 11/25/2021 - Swapped out header.php with admin.html
        $pageTitle = "Delete a Contact";
        include "admin.html";

//(13) 11/25/2021 - Lined up all varibles for the output.
//(15) 11/25/2021 - Also with the cancel button, I linked it to go back to the 
//Viewsummary page once it is selected.
    print <<<HERE
<h2>Are you sure you want to delete this record?
It will be permanently removed:</h2>
<ul>
<li>ID# $id</li>
<li>Name: $fname $lname </li>
<li>E-mail: $email</li>
<li>How long: $long</li>
<li>How many where there?: $how</li>
<li>Description: $description</li>
<li>What they did: $what</li>
<li>Other: $add</li>
</ul>
<p><br />
<form method="post" action="reallydelete.php">
<input type="hidden" name="id" value="$id">
<input type="submit" name="reallydelete" value="really truly delete" />
<input type="button" name="cancel" value="cancel"
onClick="location.href='viewsummary.php' " /></a>
</p></form>
HERE;
}//end if
else{
        print "<h1>Something has gone wrong!</h1>";
}// end else

?>