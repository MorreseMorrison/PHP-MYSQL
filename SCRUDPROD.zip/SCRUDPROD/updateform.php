<?php
//updateform.php
//connect to the database
require "dbinfo.php";
$sel_record = $_POST['sel_record'];




//11-9-2021 SCRUD 4 
$pageTitle = "Edit a Contact";
include "admin.html";
print <<<HERE
	<h2>Modify this Contact</h2>
    <p>Change the values in the text boxes then click the "Modify Record" button.</p>

	<form id = "myForm" method="POST" action = "update.php">
        <input type="hidden" name="id" value="$id">
	<div>
		<label for="fname"><b>* First name:</b></label>
		<input type="text" id="fname" name="fname" value="$fname" placeholder="First Name"><br>

	   
		<label for="lname"><b>* Last name:</b></label>
		<input type="text" id="lname" name="lname" value="$lname" placeholder="Last Name" ><br>
	  
	
		<label for="email"><b>* What is your email address?</b></label>
		<input type="email" id="email" name="email" value="$email" placeholder="Email"><br>
	  
		<label for="when"><b>When did it happen?</b></label>
		<input type="date" id="when" name="when" value="$when" placeholder="MM/DD/YYYY" ><br>
	  
		
		<label for="long"><b>How long were you gone?</b></label>
		<input type="text" id="long" name="long" value="$long" placeholder="Hours, Days, Years?"><br>
	  
		
		<label for="how"><b>How many did you see?</b></label>
		<input type="number" id="how" name="how" value="$how" placeholder="Enter a number"><br>
	  
		<label for="description"><b>Describe them:</b></label>
		<input type="text" id="description" name="description" value="$description" placeholder="What did they look like?"><br>
	  
		<label for="what"><b>What did they do to you?</b></label>
		<input type="text" id="what" name="what" value="$what" placeholder="Describe what they did"><br>
	  
		<div class="col-75">
		</div>
	  
		<p><b>*Have you seen my dog Fluffly?</b></p>
	  
		
		<label>
		  <input type="radio" id="yes" name="radioExample" value="yes">Yes
		</label>
	  
		<label>
		  <input type="radio" id="no" name="radioExample" value="no">No
		</label>
		
	  	
		<br>
		<br>
	  
	
		<label for="add"><b>Anything else you want to add?</b></label>
		<textarea id="add" name="add"  style="height:25px" placeholder="Your comments..."></textarea>
		<br>
		<br>
	
	<div id="mySubmit">
	    <input type="submit" name="submit" value="Modify Record">
	</div>
	</form>

HERE;

//SQL statement to select record to edit - 11-9-2021
$query = "SELECT * FROM aliens_abduction WHERE id = $sel_record";


// execute SQL query and get result
   ////11-9-2021 SCRUD 4 
   if($result = mysqli_query($connection,$sql)){
	//Loop Through Record and Get Values
	while ($record = mysqli_fetch_array($result)) {
			$id = $record['id'];
			$fname = $record['first_name'];
			$lname = $record['last_name'];
			$email = $record['email'];
			$when=$record['when_it_happened'];
			$long=$record['how_long'];
			$how=$record['how_many'];
			$description=$record['alien_description'];
			$what=$record['what_they_did'];
			$add=$record['other'];
	}// end while loop
	
   }else {
	print "<h1>Something has gone wrong!</h1>";
	 exit();
	 }//end else

 
?>

