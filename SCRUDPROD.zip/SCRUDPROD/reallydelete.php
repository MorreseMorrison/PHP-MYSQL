<?php
//reallydelete.php
//gets $id from confirmdelete.php
//finds matching id in database and deletes
//shows confirmation that record has been deleted

//11-9-2021 SCRUD 3
//connect to database
require "dbinfo.php";

if(isset( $_POST['reallydelete']) && $_POST['reallydelete'] == "really truly delete") {
            $id = $_POST['id'];
    //now delete the contact
    // (14) 11/25/2021 - Changed from contacts to aliens_abduction table
    $sql = "DELETE FROM aliens_abduction WHERE id = '$id'";

    if ($result = mysqli_query($connection, $sql)) {

        $pageTitle = "Contact Deleted";
        // (15) 11/25/2021 - Changed to admin.html
        include "admin.html";
        print "<p> Record $id has been permanently deleted.
        </p>";
         }
         //end if
        else {
            print "<h1>Something has gone wrong!</h1>";
        }

}
?>

