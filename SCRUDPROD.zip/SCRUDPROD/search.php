<?php
//search.php
//database connection info
include "dbinfo.php";
$search=$_POST['search'];

//11-9--2021 SCRUD 3
//SQL statement to select what to search
//(8) 11/24/2021 -Removed ORDER BY ASC as well as Like Phone #s
//(9) 11/24/2021 - Added "id like" so you can search by id numbers
$query="SELECT * FROM aliens_abduction
WHERE email like '%$search%' OR
first_name like '%$search%' OR
id like '%$search%' OR
last_name like '%$search%' ";


//(7) 11/24/2021 - Switched header.php with admin.html
// run sql statement
if ($result = mysqli_query($connection, $query)){
    // find out how many matches
    $count = mysqli_num_rows($result);
    $pageTitle="Search Results";
    include "admin.html";
print <<<HERE
<h2>Search Results</h2>
<h3>$count results found seaching for "$search"</h3>
<table cellpadding="15">
HERE;
//loop through results and get variables
//(10) 11/25/2021 - Updated the output varibles to match with the Requirements and MYSQL Table
    while ($row=mysqli_fetch_array($result)){
        $id=$row['id'];
		$fname=$row['first_name'];
		$lname=$row['last_name'];
		$email=$row['email'];
		$when=$row['when_it_happened'];
        $long=$row['how_long'];
        $how=$row['how_many'];
        $description=$row['alien_description'];
        $what=$row['what_they_did'];
        $add=$row['other'];

//(11) 11/25/2021 - Updated the output varibles to match with the Requirements and MYSQL Table
        print <<<HERE
			<tr>
			<td><strong>$fname $lname </strong><br/>
			ID# $id <br>
			When It Happened: $when <br>
			Email: $email <br>
            How long? $long <br>
            How many where there? $how <br>
            Description: $description <br>
            What they did: $what <br>
            Other: $add <br/>
				

				
HERE;
    } //end while
}else{
    echo "There was a problem with the query.";
}
print "</tr></table></body></html>";
?>

