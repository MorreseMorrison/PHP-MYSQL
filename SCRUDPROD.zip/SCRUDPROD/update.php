<?php
//update.php
//connect to the database
require "dbinfo.php";

//11-9-2021 SCRUD 4
//clean and sanitize the incoming data
if($_POST['submit']=="Submit") {
    $fname = filter_var($_POST['fname'], FILTER_SANITIZE_STRING);
    $lname = filter_var($_POST['lname'], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $when = filter_var($_POST['when'], FILTER_SANITIZE_STRING);
    $long = filter_var($_POST['long'], FILTER_SANITIZE_STRING);
    $how = filter_var($_POST['how'], FILTER_SANITIZE_NUMBER_INT);
    $description = filter_var($_POST['description'], FILTER_SANITIZE_STRING);
    $what = filter_var($POST['what'], FILTER_SANITIZE_STRING);
    $add = filter_var($_POST['add'], FILTER_SANITIZE_STRING);


}//end if

//11-9-2021 SCRUD 4
//create a safe sql query
$query = "UPDATE aliens_abduction SET
    email = '$email',
    first_name = '$fname',
    last_name = '$lname',
    when_it_happened = '$when',
    how_long ='$long',
    when_it_happened = '$when',
    how_many = '$how',
    alien_description = '$description',
    what_they_did = '$what',
    fluffy_spotted = '$radioExample',
    other = '$add' ";




if ($result = mysqli_query($connection, $query)) {
    //show confirmation
    print "<html><head><title>Update Results</title></head><body>";
    $pageTitle = "Record Updated";
    include "admin.html";
    print <<<HERE
    <h1>The new record looks like this: </h1>
    <p><strong>E-mail:</strong> $email</p>
    <p><strong>First:</strong> $fname</p>
    <p><strong>Last:</strong> $lname</p>

HERE;
}else{
    print "<h1>Something has gone wrong!</h1>";
    exit();
}//end else

?>