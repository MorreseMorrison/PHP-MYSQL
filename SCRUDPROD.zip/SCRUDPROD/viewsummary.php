<?php

//1. Make Connection to database
// (2) 11/24/2021 - Added "admin.html" so there is a layout.
require "dbinfo.php";
include "admin.html";

//2. setup safe query
// (1) 11/24/2021 - Changed from "contacts" to "aliens_abduction".
// (3) 11/24/2021 - Deleted "ORDER BY ASC", for some reason that clause was inteferring with the Query running.
$query = "Select * FROM aliens_abduction ";

//3. run the query
if ($result=mysqli_query($connection, $query)){


	//4. read the results
	$count = mysqli_num_rows($result);
	echo "Number of Contacts: ($count)<br>";

	//Added 11-9-2021
	// (7) 11/24/2021 - Removed or <a href="addsimple.php">add new contacts which is adding a new contacts from the view summary result.
	print <<<HERE
	<h2>My Contacts</h2>
	Select a record to edit or delete. </a>
		<table id="home">
	HERE;

	
		//loop to get all the records
		//(4) 11/24/2021 - Switched out the appropriate variables also matched up the appropriate MYSQL Coulmn Names as well.
		while ($row=mysqli_fetch_array($result)){
			$id=$row['id'];
			$fname=$row['first_name'];
			$lname=$row['last_name'];
			$email=$row['email'];
			$when=$row['when_it_happened'];
			

			//name="sel_record" value="$id" mentioned in SCRUD 3 Part 1 3:46 11-9-2021
			//(5) 11/24/2021 - Edited the Varible Layout so it can be more aesthetically pleasing.
			// (12) 11/25/2021 - Had to reconfigure the button layouts. Select #ID was not being 
			//Feed to confirmdelete.php. Make sure all of the varibles and buttons are 
			//Within the same tags.
			print <<<HERE
			<tr>

			<td><strong>$fname $lname</strong><br />
			Email: $email<br>
			ID# $id <br>
			When it happed:$when</td>
			<td>
			<form method="post" action="confirmdelete.php">
			<input type="hidden" name="sel_record" value="$id"> 
			<input type="submit" name="delete" value=" Delete ">
			</form>

			<form method="post" action="updateform.php">
			<input type="hidden" name="sel_record" value="$id">
			<input type="submit" name="update" value=" Edit "></form>
			</td>   
		
			</tr>
				
					
				
HERE; }//end while

	}
	else{
		echo "There was an issue with the query.";
	}
		
		

		
		?>