<!DOCTYPE html>
<html lang ="en">
<head>
    <title>First PHP Script</title>
    <meta charset = "utf-8">
</head>
<body>
    
<?php
/*
echo "<h1>Hello World Wide Web!</h>"; //comment
print"<p>This is my first PHP program.</p>"; #another comment
*/

print "It is often said \"The Truth is Rarely Pure\"";
?>
</body>
</html>